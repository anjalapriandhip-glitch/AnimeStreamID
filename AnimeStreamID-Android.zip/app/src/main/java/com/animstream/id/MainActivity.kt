package com.animestream.id

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

data class AnimeResponse(val data: List<Anime> = emptyList())
data class AnimeSingleResponse(val data: Anime)
data class Anime(
    val mal_id: Int,
    val title: String,
    val title_english: String?,
    val images: Images?,
    val synopsis: String?,
    val episodes: Int?,
    val status: String?,
    val score: Double?,
    val year: Int?,
    val genres: List<Genre> = emptyList()
)
data class Images(val jpg: Jpg?)
data class Jpg(val image_url: String?, val large_image_url: String?)
data class Genre(val name: String)

interface JikanApi {
    @GET("seasons/now")
    suspend fun currentSeason(@Query("page") page: Int = 1): AnimeResponse
    @GET("anime")
    suspend fun search(@Query("q") q: String, @Query("page") page: Int = 1): AnimeResponse
    @GET("anime/{id}/full")
    suspend fun detail(@Path("id") id: Int): AnimeSingleResponse
}

object Api {
    val service: JikanApi = Retrofit.Builder()
        .baseUrl("https://api.jikan.moe/v4/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(JikanApi::class.java)
}

class AnimeViewModel : ViewModel() {
    var home by mutableStateOf<List<Anime>>(emptyList())
        private set
    var results by mutableStateOf<List<Anime>>(emptyList())
        private set
    var selected by mutableStateOf<Anime?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    init { loadHome() }

    fun loadHome() {
        viewModelScope.launch {
            loading = true; error = null
            try { home = Api.service.currentSeason().data }
            catch (e: Exception) { error = "Gagal memuat data. Periksa koneksi internet." }
            finally { loading = false }
        }
    }

    fun search(q: String) {
        if (q.isBlank()) return
        viewModelScope.launch {
            loading = true; error = null
            try { results = Api.service.search(q).data }
            catch (e: Exception) { error = "Pencarian gagal." }
            finally { loading = false }
        }
    }

    fun open(id: Int) {
        viewModelScope.launch {
            loading = true; error = null
            try { selected = Api.service.detail(id).data }
            catch (e: Exception) { error = "Detail anime gagal dimuat." }
            finally { loading = false }
        }
    }
}

@Composable
fun Poster(anime: Anime, modifier: Modifier = Modifier) {
    AsyncImage(
        model = anime.images?.jpg?.large_image_url ?: anime.images?.jpg?.image_url,
        contentDescription = anime.title,
        modifier = modifier.clip(MaterialTheme.shapes.medium),
        contentScale = ContentScale.Crop
    )
}

@Composable
fun AnimeCard(anime: Anime, onClick: () -> Unit) {
    Column(
        Modifier.width(150.dp).clickable(onClick = onClick)
    ) {
        Poster(anime, Modifier.fillMaxWidth().height(210.dp))
        Spacer(Modifier.height(6.dp))
        Text(anime.title, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
        Text(
            "${anime.score?.let { "%.1f".format(it) } ?: "-"} • ${anime.status ?: "-"}",
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
fun HomeScreen(vm: AnimeViewModel, onOpen: (Int) -> Unit) {
    var query by remember { mutableStateOf("") }
    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("AnimeStream ID", style = MaterialTheme.typography.headlineMedium)
            Text("Anime terbaru & katalog online", style = MaterialTheme.typography.bodyMedium)
        }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Cari anime") },
                trailingIcon = {
                    TextButton(onClick = { vm.search(query) }) { Text("Cari") }
                }
            )
        }
        if (vm.loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        vm.error?.let { msg -> item { Text(msg, color = MaterialTheme.colorScheme.error) } }
        item { Text("Sedang Tayang", style = MaterialTheme.typography.titleLarge) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(vm.home) { anime -> AnimeCard(anime) { onOpen(anime.mal_id) } }
            }
        }
        if (vm.results.isNotEmpty()) {
            item { Text("Hasil Pencarian", style = MaterialTheme.typography.titleLarge) }
            items(vm.results) { anime -> AnimeCard(anime) { onOpen(anime.mal_id) } }
        }
    }
}

@Composable
fun DetailScreen(vm: AnimeViewModel, onBack: () -> Unit) {
    val anime = vm.selected ?: return
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            TextButton(onClick = onBack) { Text("← Kembali") }
            Poster(anime, Modifier.fillMaxWidth().height(360.dp))
            Spacer(Modifier.height(10.dp))
            Text(anime.title, style = MaterialTheme.typography.headlineSmall)
            anime.title_english?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            Text("⭐ ${anime.score ?: "-"}   •   ${anime.episodes ?: "?"} episode   •   ${anime.status ?: "-"}")
            Text(anime.genres.joinToString(" • ") { it.name })
        }
        item {
            Text(anime.synopsis ?: "Sinopsis belum tersedia.")
        }
        item {
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val title = Uri.encode(anime.title)
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.crunchyroll.com/search?q=$title"))
                    MainActivityHolder.activity?.startActivity(intent)
                }
            ) { Text("Tonton Resmi") }
        }
        item {
            Text("Catatan: tombol ini membuka pencarian di layanan resmi. Ketersediaan judul dapat berbeda menurut negara dan lisensi.")
        }
    }
}

object MainActivityHolder { var activity: ComponentActivity? = null }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MainActivityHolder.activity = this
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme()
            ) {
                val vm: AnimeViewModel = viewModel()
                var detail by remember { mutableStateOf(false) }
                if (detail && vm.selected != null) {
                    DetailScreen(vm) { detail = false }
                } else {
                    HomeScreen(vm) { id -> vm.open(id); detail = true }
                }
            }
        }
    }
    override fun onDestroy() {
        MainActivityHolder.activity = null
        super.onDestroy()
    }
}
